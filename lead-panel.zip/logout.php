<?php
session_start();
session_unset();
session_destroy();

$location = 'login';

if($_SESSION["role"] == 'allow'){

    }else{
    header( "Location: $location" );
    }
?>