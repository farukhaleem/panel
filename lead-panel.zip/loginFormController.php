<?php
session_start();
include('dbconnection.php');

if(isset($_POST['username']) && $_POST['username'] != ''){


$username = htmlspecialchars($_POST['username']);
$password = md5($_POST['password']);


$sql = "SELECT * FROM `dbapp_panel_users` WHERE username = '".$username."' && password = '".$password."'";


$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) == 1) {

  while($row = mysqli_fetch_assoc($result)) {
    $_SESSION["username"] = $row["username"];
    $_SESSION["role"] = "allow";
    echo 'success';
      
  }
  
  
} else {  echo 'username or password is incorrect !'; }


}else{
    echo 'username or password is incorrect !';
}

?>