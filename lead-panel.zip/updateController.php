<?php
include('dbconnection.php');

if(isset($_POST['form']) && $_POST['form'] != ''){

$sql = 'SELECT * FROM '.$_POST['form'].' WHERE date >= NOW() - INTERVAL 10 SECOND';
$result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
         $return_arr = $row;

         foreach($obj as $key){
                $return_arr[] = $key;
            }
         $return_arr['form'] =  $_POST['form'];         
         echo json_encode($return_arr);
      }
    }

    
}

?>