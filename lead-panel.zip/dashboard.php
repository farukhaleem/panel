<?php
session_start();

if($_SESSION["role"] == 'allow'){
    
}else{
$location = 'login';
header( "Location: $location" );
}

include('dbconnection.php');
?>

<!doctype html>
<html class="no-js" lang="en">
<!--<meta http-equiv="refresh" content="5">-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Data Table | <?php echo $brand; ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="icon" href="/favicon.ico" type="image/x-icon" />
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="css/main.css">
     <link rel="stylesheet" href="css/modals.css">
    <!-- educate icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <!-- x-editor CSS
		============================================ -->
    <link rel="stylesheet" href="css/editor/select2.css">
    <link rel="stylesheet" href="css/editor/datetimepicker.css">
    <link rel="stylesheet" href="css/editor/bootstrap-editable.css">
    <link rel="stylesheet" href="css/editor/x-editor-style.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
		============================================ -->

<style type="text/css">
.tabs{display: none;}    
.tabs.current{display: block;}
.sidebar-nav .metismenu li.current a{color:#fff; background: #006df0; }
.sidebar-header{padding:20px;}
.sidebar-nav .metismenu a, .main-sparkline13-hd, .fixed-table-body thead th .th-inner {text-transform: capitalize;}
.main-logo.mobile{ width:150px; margin:50px;}
.main-logo.mobile{width:0;}
.unread{background: #006df0 !important; color:#fff !important;}

@media (max-width: 1024px){
.comment-scrollbar{height:auto;}
.left-sidebar-pro{width:100%; display:block;}
#sidebar{width:100%; height:auto; position: relative;}
.logo-pro{display:none;}    

.all-content-wrapper { margin-left: 0px;}

    
}

</style>


    <script src="js/vendor/modernizr-2.8.3.min.js"></script>


</head>

<body>
    
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href=""><img class="main-logo" src="<?php echo 'img/'.$logo; ?>" alt="<?php echo $brand; ?>" width="150px"/></a>
                <strong><a href=""><img src="<?php echo 'img/'.$icon; ?>" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="has-arrow" href="javascript:;" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Data Tables</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                
                                <?php
                                $get_tables_query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA= '".$mysql_database."' AND TABLE_NAME NOT LIKE '%dbapp%'";
                                $result = mysqli_query($con,$get_tables_query);
                                $count = 0 ;
                                while ($row = mysqli_fetch_array($result)) {
                                
                                if($count == 0 ){
                                ?>
                                    <li data-targetit="<?php echo $row[0] ?>" class="current"><a title="Peity Charts" href="javascript:;"><span class="mini-sub-pro"><?php echo $row[0] ?></span></a></li>                                
                                
                                <?php }else{ ?>
                                
                                    <li data-targetit="<?php echo $row[0] ?>"><a title="Peity Charts" href="javascript:;"><span class="mini-sub-pro"><?php echo $row[0] ?></span></a></li>                                
                                
                                <?php } ?>
                                <?php $count++; } ?>
                                
                            </ul>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- End Left menu area -->
    
    
    
    
    
    
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href=""><img class="main-logo mobile" src="<?php echo 'img/'.$logo; ?>" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="educate-icon educate-nav"></i>
												</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                                <li class="nav-item">
                                                    <a href="javascript:;" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<span class="admin-name"><?php echo $_SESSION["username"]; ?></span>
															<i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
														</a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        <li><a href="logout"><span class="edu-icon edu-locked author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
        </div>
        
        
        
        
<?php
$get_tables_query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA= '".$mysql_database."' AND TABLE_NAME NOT LIKE '%dbapp%'";
$result_tb = mysqli_query($con,$get_tables_query);
$count_tb = 0 ;

$table_arr = array();
while ($table_name = mysqli_fetch_array($result_tb)) {
array_push($table_arr, $table_name[0]);

if($count_tb == 0 ){
?>
    <div class="tabs <?php echo $table_name[0]; ?> current data-table-area mg-b-15">
        
<?php }else{ ?>

    <div class="tabs <?php echo $table_name[0]; ?> data-table-area mg-b-15">                               

<?php } 
    $table = $table_name[0];

?>        
        <!-- Static Table Start -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1><?php echo $table ; ?> | <span class="table-project-n">Data</span> Table</h1>
                                </div>
                            </div>
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    <table id="<?php echo $table ; ?>" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId"  data-click-to-select="true" data-toolbar="#toolbar">
                                       <input type="hidden" id="form" name="form" value="<?php echo $table ; ?>" > 
<?php
$get_col_query = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='".$mysql_database."' AND `TABLE_NAME`='".$table."';";
$result = mysqli_query($con,$get_col_query);
?>

                                        <thead>
                                            <tr>
<?php 
// print_r($table_arr);

$table_arr[$table_name[0]] = array();
$i = 0;
while ($row = mysqli_fetch_array($result)) {
array_push($table_arr[$table], $row[0]);
?>
                                                <th data-field="<?php echo $table_arr[$table][$i] ; ?>"><?php echo $table_arr[$table][$i] ; ?></th>
<?php $i++; } ?>
                                            </tr>
                                        </thead>

                                        <tbody>


<?php

$sql = "SELECT * FROM `".$table_name[0]."` order by id desc";

$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
?>                                            
                                            <tr>
                                                <?php for($a = 0; $a < $i; $a++){ ?>                                            
                                                <td><?php echo $row[$table_arr[$table][$a]]; ?></td>
                                                <?php } ?>
                                            </tr>
<?php
  }
} else {
  echo "0 results";
}

?>
  
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $count_tb++; } ?>




        
        <!-- Static Table End -->
        <div id="PrimaryModalalert" class="modal modal-edu-general default-popup-PrimaryModal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-close-area modal-close-df">
                        <a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
                    </div>
                    <div class="modal-body">
                        <i class="educate-icon educate-checked modal-check-pro"></i>
                        <h2>New Sign Up!</h2>
                        <!--<p></p>-->
                    </div>
                    <div class="modal-footer">
                        <a data-dismiss="modal" href="#">Close</a>
                        <!--<a href="javascript:;">Process</a>-->
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="footer-copy-right">
                            <p>© 2020 <?php echo $brand; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jquery
		============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- data table JS
		============================================ -->
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
		============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
    <!-- Chart JS
		============================================ -->
    <script src="js/chart/jquery.peity.min.js"></script>
    <script src="js/peity/peity-active.js"></script>


    <!-- tab JS
		============================================ -->
    <script src="js/tab.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="js/main.js"></script>
    <!-- tawk chat JS
		============================================ -->


<script type="text/javascript">
    
    $('[data-targetit]').on('click',function () {
        $(this).siblings().removeClass('current');
        $(this).addClass('current');
        var target = $(this).data('targetit');
        $('.'+target).siblings('[class^="tabs"]').removeClass('current');
        $('.'+target).addClass('current');
        
    });    


<?php  
// $count_tb = count($table_arr)/2;
// echo $count_tb; 
// print_r($table_arr);

?>


function start(counter){
  if(counter < 600){
    
  
    setTimeout(function(){
      counter++;
    
    var tables = <?php echo '['; for($s = 0; $s < $count_tb; $s++ ){ if($s == '0'){ } else{echo ','; } echo '"'.$table_arr[$s].'"' ; } echo ']';  ?> ;
    var i = 0;
    
    for (;tables[i];) {
    
    var values = { 'form': tables[i] };
    
    var data = $('#form').val();
    var form_data = new FormData();
    form_data.append("form", data);
    
    $.ajax({
        type: 'POST',
        url: 'updateController.php',
        data: values,
        dataType: 'JSON',
        error: function()
        {
        //   alert("Request Failed");
        },
        success: function(response)
        { 
                
            if(response >'0'){
            // console.log(response);
                $('#PrimaryModalalert').modal('show');
                switch(response.form) {


                  <?php for($s = 0; $s < $count_tb; $s++ ){ 
                      if($s == '0'){ } else{ } echo 'case "'.$table_arr[$s].'" :' ; 
                      ?>
                   
                    $("#"+response.form).bootstrapTable('insertRow', {
                        index: 0,
                        row: {
                            
                            <?php $val = $table_arr[$s]; for($b = 0; $b < count($table_arr[$val]); $b++ ){ 
                              if($b == '0'){ } else{ echo ','; } echo $table_arr[$val][$b].' : response.'.$table_arr[$val][$b] ; 
                            ?>

                            <?php } ?>                        
                            
                	       }
                      });
              
                  
                  <?php echo 'break; '; }  ?>
                  
                  default:
                }
                  
                  $('[data-targetit="'+response.form+'"]').siblings().removeClass('current');
                  $('[data-targetit="'+response.form+'"]').addClass('current');
                  
                  var target = $('[data-targetit="'+response.form+'"]').data('targetit');
                  $('.'+target).siblings('[class^="tabs"]').removeClass('current');
                  $('.'+target).addClass('current');
                  
                  $("#"+response.form+" tbody tr[data-index='0']").attr('onclick','read(this)');
                  $("#"+response.form+" tbody tr[data-index='0']").addClass('unread');
                
                
            
            }else{
            }

        }
        
    });
    
        i++;
    }

    
    //   function end  
      start(counter);
    }, 10000);
  }else{ window.location.href= "logout"; }
}
start(0);


</script>


<script> 

function read(a){
    $(a).removeClass('unread');
}


    </script>
    
</body>

</html>