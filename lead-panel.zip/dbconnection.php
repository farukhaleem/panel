<?php
$mysql_hostname = "localhost";
$mysql_user = "";
$mysql_password = "";
$mysql_database = "";

$con = mysqli_connect($mysql_hostname,$mysql_user,$mysql_password,$mysql_database);

/*
// Check connection
if (mysqli_connect_errno()){ echo "Failed to connect to MySQL: " . mysqli_connect_error();}
else{ echo "connected";}
*/

$brand = 'Alpha';
$logo = 'logo.png';
$icon = 'logo-icon.png';

// https://www.w3schools.com/php/phptryit.asp?filename=tryphp_func_string_md5

?>