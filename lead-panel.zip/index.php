<?php
session_start();

if($_SESSION["username"] == 'admin'){
    print_r($_SESSION);
}else{
$location = 'login';
header( "Location: $location" );
}

?>


<a href="logout.php">Logout</a>