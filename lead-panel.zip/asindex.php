<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css" type="text/css" />
    
<style>
 
</style>    

</head>

<?php

include('dbconnection.php');


$sql = "SELECT * FROM `banner_inquiry` ORDER BY id DESC";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {

?>

<div class="container"><div class="row"> <div class="col-md-12"> 
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Number</th>
                <th>Country</th>
                <th>Country Code</th>
                <th>IP</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
<?php
  while($row = mysqli_fetch_assoc($result)) {
?>
            <tr>
                <td><?php echo $row["id"]; ?></td>
                <td><?php echo $row["bn_name"]; ?></td>
                <td><?php echo $row["bn_email"]; ?></td>
                <td><?php echo $row["bn_number"]; ?></td>
                <td><?php echo $row["country_name"]; ?></td>
                <td><?php echo $row["country_code"]; ?></td>
                <td><?php echo $row["ip"]; ?></td>
                <td><?php echo $row["date"]; ?></td>
            </tr>

<?php
  }
} else {
  echo "0 results";
}

?>

        </tbody>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Number</th>
                <th>Country</th>
                <th>Country Code</th>
                <th>IP</th>
                <th>Date</th>
            </tr>
        </tfoot>
    </table>
</div> </div> </div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    $('#example').DataTable( {
        "order": [[ 0, "desc" ]],
        
    } );
} );   
    
    
    
    
</script>